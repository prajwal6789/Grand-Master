import os
import time
import requests
import pandas as pd


PROCESSED_PATH = os.path.join("data", "processed", "appstore_cleaned.csv")

# RapidAPI credentials
RAPIDAPI_KEY = "409a6f86a6mshaaebc328d9356a3p152b16jsnc21024911d94"
RAPIDAPI_HOST = "apple-app-store-scraper.p.rapidapi.com"


DETAILS_URL = f"https://{RAPIDAPI_HOST}/v1/appstore"


def fetch_app_data(app_id, retries=3, delay=2):
    headers = {
        "x-rapidapi-key": RAPIDAPI_KEY,
        "x-rapidapi-host": RAPIDAPI_HOST
    }

    params = {"appid": app_id, "country": "us"}

    for attempt in range(retries):
        try:
            response = requests.get(DETAILS_URL, headers=headers, params=params, timeout=10)
            print(f"🔎 Querying AppID {app_id} → Status {response.status_code}")

            if response.status_code == 200:
                data = response.json()
                print("📜 Raw API Response:", data)
                return data
            else:
                print(f"⚠️ API Error {response.status_code} for AppID {app_id}")
                print("Response text:", response.text)
                time.sleep(delay)

        except Exception as e:
            print(f"❌ Request failed for AppID {app_id}: {e}")
            time.sleep(delay)

    return None


def normalize_appstore_data(raw_data_list):
    """
    Map raw App Store API data into unified schema.
    """
    normalized = []

    for item in raw_data_list:
        try:
            app_data = item.get("data", {})

            normalized.append({
                "app_name": app_data.get("title"),
                "category": app_data.get("primaryGenre"),
                "genres": ", ".join(app_data.get("genres", [])),
                "description": app_data.get("description"),
                "rating": app_data.get("score"),
                "current_version_rating": app_data.get("currentVersionScore"),
                "reviews": app_data.get("reviews"),
                "current_version_reviews": app_data.get("currentVersionReviews"),
                "price": app_data.get("price", 0.0),
                "is_free": app_data.get("free"),
                "content_rating": app_data.get("contentRating"),
                "last_updated": app_data.get("updated"),
                "release_notes": app_data.get("releaseNotes"),
                "developer": app_data.get("developer"),
                "platform": "App Store"
            })
        except Exception as e:
            print(f"⚠️ Error normalizing item: {e}")

    return pd.DataFrame(normalized)



def run_appstore_ingestion(app_ids):
    """
    Fetch and save app details for a list of App IDs.
    """
    all_data = []

    for app_id in app_ids:
        result = fetch_app_data(app_id)
        if result:
            all_data.append(result)
        time.sleep(1) 

    df = normalize_appstore_data(all_data)

    os.makedirs(os.path.dirname(PROCESSED_PATH), exist_ok=True)
    df.to_csv(PROCESSED_PATH, index=False)
    print(f"📂 App Store cleaned data saved at {PROCESSED_PATH}")

    return df


if __name__ == "__main__":
    # Example app IDs
    sample_app_ids = ["544007664", "310633997", "447188370", "324684580"]

    df_appstore = run_appstore_ingestion(sample_app_ids)
    print(df_appstore.head())
