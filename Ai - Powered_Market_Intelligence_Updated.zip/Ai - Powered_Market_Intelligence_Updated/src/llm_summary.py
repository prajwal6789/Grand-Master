import os
import json
from dotenv import load_dotenv
from groq import Groq

# Load environment variables (make sure GROQ_API_KEY is set in your .env)
load_dotenv()

# Paths
INSIGHTS_PATH = os.path.join("reports", "insights.json")
SUMMARY_PATH = os.path.join("reports", "executive_summary.md")

def load_insights():
    with open(INSIGHTS_PATH, "r") as f:
        return json.load(f)

def generate_summary_with_llama(insights):
    client = Groq(api_key=os.getenv("GROQ_API_KEY"))

    prompt = f"""
    You are an AI business analyst with expertise in app marketplaces and eCommerce.
    You will receive structured insights (in JSON format) from a data pipeline.
    Your task is to write a clear, concise, and actionable *executive summary* for a product manager.

    ### Instructions:
    - Write in **Markdown format** with clear sections.
    - Always include:
    - **Key Findings** (bullet points with metrics)
    - **Strategic Recommendations** (2-3 specific actions)
    - **Confidence Levels** (map JSON confidence values to High / Medium / Low)
    - Avoid technical jargon. Keep it business-friendly.
    - Length: 200-300 words max.

    ### Example:
    Insights JSON:
    [
    {{
        "insight": "Top categories by downloads",
        "details": {{"Games": 5000000, "Productivity": 2000000}},
        "confidence": 0.9,
        "recommendation": "Focus marketing spend on games"
    }}
    ]

    Expected Output:
    **Executive Summary**

    #### Key Findings
    - Games lead with 5M downloads, followed by Productivity with 2M.

    #### Strategic Recommendations
    - Allocate higher marketing budget to Games.
    - Maintain moderate investment in Productivity apps.

    #### Confidence Levels
    - Insights supported with **High confidence (0.9)**.

    ---

    ### Now, generate the summary for these insights:
    {json.dumps(insights, indent=4)}
    """


    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",  # Groq LLaMA model
        messages=[
            {"role": "system", "content": "You are a market analyst AI."},
            {"role": "user", "content": prompt},
        ],
        temperature=0.6,
        max_tokens=800
    )

    return response.choices[0].message.content.strip()

def run_summary():
    insights = load_insights()
    summary_text = generate_summary_with_llama(insights)

    os.makedirs(os.path.dirname(SUMMARY_PATH), exist_ok=True)
    with open(SUMMARY_PATH, "w", encoding="utf-8") as f:
        f.write(summary_text)

    print(f" Executive summary saved at {SUMMARY_PATH}")
    print("\n Preview:\n")
    print(summary_text[:800])

if __name__ == "__main__":
    run_summary()
