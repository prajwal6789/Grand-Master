import pandas as pd
import os

# Paths
RAW_DATA_PATH = os.path.join("data", "raw", "googleplaystore.csv")
PROCESSED_PATH = os.path.join("data", "processed", "google_play_cleaned.csv")

def load_google_play_data(path=RAW_DATA_PATH):
    """Load raw Google Play Store dataset."""
    try:
        df = pd.read_csv(path)
        print(f" Loaded dataset with {len(df)} rows and {len(df.columns)} columns")
        return df
    except Exception as e:
        print(f" Error loading dataset: {e}")
        return None

def clean_google_play_data(df):
    """Clean and normalize Google Play dataset."""
    if df is None:
        return None

    # Drop duplicates
    df = df.drop_duplicates()

    # Fill missing ratings with mean
    if "Rating" in df.columns:
        df["Rating"] = df["Rating"].fillna(df["Rating"].mean())

    # Reviews → numeric
    if "Reviews" in df.columns:
        df["Reviews"] = pd.to_numeric(df["Reviews"], errors="coerce").fillna(0).astype(int)

    # Installs → clean + convert
    if "Installs" in df.columns:
        df["Installs"] = (
            df["Installs"].astype(str)
            .str.replace(r"[+,]", "", regex=True)
            .replace("Free", "0")
        )
        df["Installs"] = pd.to_numeric(df["Installs"], errors="coerce").fillna(0).astype(int)

    # Size → MB
    if "Size" in df.columns:
        def size_to_mb(x):
            x = str(x)
            if "M" in x:
                return float(x.replace("M", ""))
            elif "k" in x:
                return round(float(x.replace("k", "")) / 1024, 3)
            elif x == "Varies with device":
                return None
            else:
                return None
        df["Size_MB"] = df["Size"].apply(size_to_mb)

    # Price → remove $ and convert
    if "Price" in df.columns:
        df["Price"] = (
            df["Price"].astype(str).str.replace("$", "", regex=False)
        )
        df["Price"] = pd.to_numeric(df["Price"], errors="coerce").fillna(0.0)

    # Content Rating → fix missing
    if "Content Rating" in df.columns:
        df["Content Rating"] = df["Content Rating"].fillna("Unrated")

    print(" Google Play dataset cleaned successfully")
    return df


def save_cleaned_data(df, path=PROCESSED_PATH):
    """Save cleaned dataset to processed folder."""
    if df is not None:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        df.to_csv(path, index=False)
        print(f" Cleaned data saved at {path}")

if __name__ == "__main__":
    df = load_google_play_data()
    df_clean = clean_google_play_data(df)
    save_cleaned_data(df_clean)
