import os
import pandas as pd
import json
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

# Paths
D2C_PATH = os.path.join("data", "raw", "Kasparro_Phase5_D2C_Synthetic_Dataset.xlsx")
REPORT_PATH = os.path.join("reports", "d2c_insights.json")

def load_d2c_data():
    df = pd.read_excel(D2C_PATH)
    print(f"✅ Loaded D2C dataset with {df.shape[0]} rows, {df.shape[1]} columns")
    return df

def compute_metrics(df):
    insights = {}

    # Normalize column names (lowercase, no spaces)
    df.columns = [c.strip().lower().replace(" ", "_") for c in df.columns]

    
    if "ad_spend" in df.columns and "conversions" in df.columns:
        df["cac"] = df["ad_spend"] / df["conversions"].replace(0, pd.NA)
        avg_cac = df["cac"].mean(skipna=True)
    else:
        avg_cac = None

    
    if "revenue" in df.columns and "ad_spend" in df.columns:
        df["roas"] = df["revenue"] / df["ad_spend"].replace(0, pd.NA)
        avg_roas = df["roas"].mean(skipna=True)
    else:
        avg_roas = None

    
    if "repeat_purchase" in df.columns and "first_purchase" in df.columns:
        retention_rate = df["repeat_purchase"].sum() / max(1, df["first_purchase"].sum())
    else:
        retention_rate = None

    insights["funnel"] = {
        "avg_cac": avg_cac,
        "avg_roas": avg_roas,
        "retention_rate": retention_rate
    }

    # SEO opportunities
    if all(col in df.columns for col in ["category", "search_volume", "average_position", "conversion_rate"]):
        seo = df.groupby("category").agg({
            "search_volume": "mean",
            "average_position": "mean",
            "conversion_rate": "mean"
        }).reset_index()

        seo["opportunity_score"] = seo["search_volume"] / (seo["average_position"] + 1) * seo["conversion_rate"]
        seo_opps = seo.sort_values("opportunity_score", ascending=False).head(5)
        insights["seo_opportunities"] = seo_opps.to_dict(orient="records")

    return insights


def generate_creatives(insights):
    client = Groq(api_key=os.getenv("GROQ_API_KEY"))

    prompt = f"""
    You are an AI marketing strategist analyzing Direct-to-Consumer (D2C) performance data
    from app-related campaigns. The dataset includes campaign spend, impressions, clicks,
    installs, signups, first purchases, repeat purchases, SEO metrics, and revenue.

    ### Task
    Using the insights, generate a clear and actionable output with three sections:
    1. **Funnel Insights**
    - Calculate CAC (Customer Acquisition Cost = spend_usd / first_purchase).
    - Calculate ROAS (Return on Ad Spend = revenue_usd / spend_usd).
    - Identify retention patterns (repeat_purchase vs first_purchase).
    - Mention any drop-off points in the funnel.
    2. **SEO Opportunities**
    - Identify categories with high search volume but low conversion rate or poor avg_position.
    - Recommend 2-3 actionable steps for optimization.
    3. **AI-Powered Creative Outputs**
    - Provide:
        - One catchy **Ad Headline** (max 10 words)
        - One **SEO Meta Description** (150-160 characters)
        - One short **Product Detail Page (PDP) Text** (2-3 sentences)

    ### Example
    Insights JSON:
    {{
    "campaign_id": "CAMP_002",
    "channel": "Organic Search",
    "spend_usd": 559.41,
    "impressions": 17666,
    "clicks": 1563,
    "installs": 247,
    "signups": 181,
    "first_purchase": 382,
    "repeat_purchase": 268,
    "revenue_usd": 1814.35,
    "seo_category": "Astrology Services",
    "avg_position": 14.8,
    "monthly_search_volume": 40081,
    "conversion_rate": 2.46
    }}

    Expected Output:
    **Funnel Insights**
    - CAC: $1.46 (very efficient)
    - ROAS: 3.24 (strong performance)
    - Retention: 70% of first-time buyers made repeat purchases.
    - Drop-off: High impressions → moderate clicks → good conversion.

    **SEO Opportunities**
    - Astrology Services: high search volume (40k) with decent conversion (2.46%) but avg. position 14.8.
    - Opportunity: Improve keyword targeting and on-page SEO to move into top 10.
    - Recommend blog content + backlinks in Astrology niche.

    **AI-Powered Creative Outputs**
    - Ad Headline: "Discover Your Future, Today"
    - SEO Meta Description: "Personalized astrology readings with accurate insights. Trusted by thousands. Start your journey now!"
    - PDP Text: "Unlock clarity with our Astrology Services. From daily predictions to in-depth life guidance, experience accurate and personalized insights designed for you."

    ---

    ### Now generate the output for these insights:
    {json.dumps(insights, indent=4)}
    """



    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[{"role": "system", "content": "You are a marketing AI."},
                  {"role": "user", "content": prompt}],
        temperature=0.7,
        max_tokens=400
    )

    return response.choices[0].message.content.strip()

def run_analysis():
    df = load_d2c_data()
    insights = compute_metrics(df)
    creatives = generate_creatives(insights)

    insights["creatives"] = creatives

    os.makedirs(os.path.dirname(REPORT_PATH), exist_ok=True)
    with open(REPORT_PATH, "w", encoding="utf-8") as f:
        json.dump(insights, f, indent=4)

    print(f" D2C insights saved to {REPORT_PATH}")
    print("\n Preview:\n")
    print(json.dumps(insights, indent=4)[:800])

if __name__ == "__main__":
    run_analysis()
