import os
import json
import pandas as pd
import streamlit as st

# Paths
GP_PATH = os.path.join("data", "processed", "google_play_cleaned.csv")
AS_PATH = os.path.join("data", "processed", "appstore_cleaned.csv")
COMBINED_PATH = os.path.join("data", "processed", "combined_cleaned.csv")
INSIGHTS_PATH = os.path.join("reports", "insights.json")
SUMMARY_PATH = os.path.join("reports", "executive_summary.md")
D2C_PATH = os.path.join("data", "raw", "d2c_synthetic.xlsx")
D2C_REPORT = os.path.join("reports", "d2c_insights.json")

# Helpers
@st.cache_data
def load_csv(path):
    return pd.read_csv(path) if os.path.exists(path) else pd.DataFrame()

@st.cache_data
def load_json(path):
    if os.path.exists(path):
        with open(path, "r") as f:
            return json.load(f)
    return {}

@st.cache_data
def load_text(path):
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    return "No data available."

@st.cache_data
def load_excel(path):
    return pd.read_excel(path) if os.path.exists(path) else pd.DataFrame()

# Streamlit UI
st.set_page_config(page_title="AI-Powered Market Intelligence", layout="wide")
st.title("📊 AI-Powered Market Intelligence Dashboard")

tabs = st.tabs([
    "📂 Datasets",
    "📈 Insights",
    "📝 Executive Summary",
    "🛒 D2C Analysis",
    "📊 Visualizations",
    "🔎 Search & Query"
])

with tabs[0]:
    st.header("📂 Datasets Overview")
    gp = load_csv(GP_PATH)
    as_df = load_csv(AS_PATH)
    combined = load_csv(COMBINED_PATH)

    st.subheader("Google Play Store")
    st.dataframe(gp.head())

    st.subheader("Apple App Store")
    st.dataframe(as_df.head())

    st.subheader("Combined Dataset")
    st.dataframe(combined.head())
    st.info(f"Combined dataset: {combined.shape[0]} rows × {combined.shape[1]} columns")

with tabs[1]:
    st.header("📈 Insights (from combined dataset)")
    insights = load_json(INSIGHTS_PATH)
    if insights:
        for ins in insights:
            st.subheader(ins.get("insight", "Insight"))
            st.json(ins)
    else:
        st.warning("No insights available. Run `insights.py` first.")

with tabs[2]:
    st.header("📝 Executive Summary")
    summary = load_text(SUMMARY_PATH)
    st.markdown(summary)

with tabs[3]:
    st.header("🛒 D2C Analysis (Phase 5)")
    d2c = load_excel(D2C_PATH)
    if not d2c.empty:
        st.subheader("Raw D2C Dataset")
        st.dataframe(d2c.head())

    d2c_insights = load_json(D2C_REPORT)
    if d2c_insights:
        st.subheader("D2C Funnel & SEO Insights")
        st.json(d2c_insights)
    else:
        st.warning("No D2C insights available. Run `d2c_analysis.py` first.")

with tabs[4]:
    st.header("📊 Visualizations")
    combined = load_csv(COMBINED_PATH)

    if not combined.empty and "category" in combined.columns and "reviews" in combined.columns:
        st.subheader("Top 10 Categories by Reviews")
        top_cats = combined.groupby("category")["reviews"].sum().sort_values(ascending=False).head(10)
        st.bar_chart(top_cats)

    if not combined.empty and "price" in combined.columns and "rating" in combined.columns:
        st.subheader("Average Rating (Paid vs Free)")
        combined["is_paid"] = combined["price"].apply(lambda x: "Paid" if x > 0 else "Free")
        avg_ratings = combined.groupby("is_paid")["rating"].mean()
        st.bar_chart(avg_ratings)

with tabs[5]:
    st.header("🔎 Search & Query")
    combined = load_csv(COMBINED_PATH)

    if not combined.empty:
        query = st.text_input("Enter app name, category, or keyword:")
        if query:
            results = combined[
                combined.apply(lambda row: row.astype(str).str.contains(query, case=False).any(), axis=1)
            ]
            st.subheader(f"Search Results for: {query}")
            st.dataframe(results.head(20))
            st.info(f"Found {results.shape[0]} matching rows")
        else:
            st.info("Type something in the search box to see results.")
    else:
        st.warning("Combined dataset not found. Please generate it first.")
