import os
import pandas as pd

# Paths
GP_CLEANED_PATH = os.path.join("data", "processed", "google_play_cleaned.csv")
AS_CLEANED_PATH = os.path.join("data", "processed", "appstore_cleaned.csv")
COMBINED_PATH = os.path.join("data", "processed", "combined_cleaned.csv")

def load_datasets():
    gp = pd.read_csv(GP_CLEANED_PATH)
    as_df = pd.read_csv(AS_CLEANED_PATH)
    print(f" Google Play: {gp.shape[0]} rows, {gp.shape[1]} cols")
    print(f" App Store: {as_df.shape[0]} rows, {as_df.shape[1]} cols")
    return gp, as_df

def align_google_play(gp):
    # Rename to unified schema
    gp = gp.rename(columns={
        "App": "app_name",
        "Category": "category",
        "Genres": "genres",
        "Rating": "rating",
        "Reviews": "reviews",
        "Installs": "installs",
        "Price": "price",
        "Content Rating": "content_rating",
        "Last Updated": "last_updated"
    })


    for col in ["developer", "release_notes"]:
        gp[col] = None

    gp["platform"] = "Google Play"
    return gp[[
        "app_name", "category", "genres", "rating", "reviews",
        "installs", "price", "content_rating", "last_updated",
        "developer", "release_notes", "platform"
    ]]

def align_appstore(as_df):

    col_map = {
        "app_name": "app_name",
        "category": "category",
        "genres": "genres",
        "rating": "rating",
        "reviews": "reviews",
        "installs": "installs",
        "price": "price",
        "content_rating": "content_rating",
        "last_updated": "last_updated",
        "developer": "developer",
        "release_notes": "release_notes",
        "platform": "platform"
    }


    aligned = pd.DataFrame(columns=col_map.keys())
    for target_col, source_col in col_map.items():
        if source_col in as_df.columns:
            aligned[target_col] = as_df[source_col]
        else:
            aligned[target_col] = None

    return aligned

def combine_and_save():
    gp, as_df = load_datasets()
    gp_aligned = align_google_play(gp)
    as_aligned = align_appstore(as_df)

    combined = pd.concat([gp_aligned, as_aligned], ignore_index=True)
    os.makedirs(os.path.dirname(COMBINED_PATH), exist_ok=True)
    combined.to_csv(COMBINED_PATH, index=False)
    print(f" Combined dataset saved at {COMBINED_PATH}")
    print(f" Final shape: {combined.shape[0]} rows, {combined.shape[1]} cols")
    return combined

if __name__ == "__main__":
    combined_df = combine_and_save()
    print(combined_df.head())
