import os
import pandas as pd
import json
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

# Paths
D2C_PATH = os.path.join("data", "raw", "Kasparro_Phase5_D2C_Synthetic_Dataset.xlsx")
REPORT_PATH = os.path.join("reports", "d2c_insights.json")

def load_d2c_data():
    df = pd.read_excel(D2C_PATH)
    print(f"✅ Loaded D2C dataset with {df.shape[0]} rows, {df.shape[1]} columns")
    return df

def compute_metrics(df):
    insights = {}

    # Normalize column names (lowercase, no spaces)
    df.columns = [c.strip().lower().replace(" ", "_") for c in df.columns]

    
    if "ad_spend" in df.columns and "conversions" in df.columns:
        df["cac"] = df["ad_spend"] / df["conversions"].replace(0, pd.NA)
        avg_cac = df["cac"].mean(skipna=True)
    else:
        avg_cac = None

    
    if "revenue" in df.columns and "ad_spend" in df.columns:
        df["roas"] = df["revenue"] / df["ad_spend"].replace(0, pd.NA)
        avg_roas = df["roas"].mean(skipna=True)
    else:
        avg_roas = None

    
    if "repeat_purchase" in df.columns and "first_purchase" in df.columns:
        retention_rate = df["repeat_purchase"].sum() / max(1, df["first_purchase"].sum())
    else:
        retention_rate = None

    insights["funnel"] = {
        "avg_cac": avg_cac,
        "avg_roas": avg_roas,
        "retention_rate": retention_rate
    }

    # SEO opportunities
    if all(col in df.columns for col in ["category", "search_volume", "average_position", "conversion_rate"]):
        seo = df.groupby("category").agg({
            "search_volume": "mean",
            "average_position": "mean",
            "conversion_rate": "mean"
        }).reset_index()

        seo["opportunity_score"] = seo["search_volume"] / (seo["average_position"] + 1) * seo["conversion_rate"]
        seo_opps = seo.sort_values("opportunity_score", ascending=False).head(5)
        insights["seo_opportunities"] = seo_opps.to_dict(orient="records")

    return insights


def generate_creatives(insights):
    client = Groq(api_key=os.getenv("GROQ_API_KEY"))

    prompt = f"""
    You are an AI copywriter. Based on these insights:

    {json.dumps(insights, indent=4)}

    Generate:
    1. A catchy ad headline
    2. An SEO meta description
    3. A short product detail page (PDP) text
    """

    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[{"role": "system", "content": "You are a marketing AI."},
                  {"role": "user", "content": prompt}],
        temperature=0.7,
        max_tokens=400
    )

    return response.choices[0].message.content.strip()

def run_analysis():
    df = load_d2c_data()
    insights = compute_metrics(df)
    creatives = generate_creatives(insights)

    insights["creatives"] = creatives

    os.makedirs(os.path.dirname(REPORT_PATH), exist_ok=True)
    with open(REPORT_PATH, "w", encoding="utf-8") as f:
        json.dump(insights, f, indent=4)

    print(f" D2C insights saved to {REPORT_PATH}")
    print("\n Preview:\n")
    print(json.dumps(insights, indent=4)[:800])

if __name__ == "__main__":
    run_analysis()
