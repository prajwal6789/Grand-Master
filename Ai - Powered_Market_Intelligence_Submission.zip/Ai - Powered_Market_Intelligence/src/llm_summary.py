import os
import json
from dotenv import load_dotenv
from groq import Groq

# Load environment variables (make sure GROQ_API_KEY is set in your .env)
load_dotenv()

# Paths
INSIGHTS_PATH = os.path.join("reports", "insights.json")
SUMMARY_PATH = os.path.join("reports", "executive_summary.md")

def load_insights():
    with open(INSIGHTS_PATH, "r") as f:
        return json.load(f)

def generate_summary_with_llama(insights):
    client = Groq(api_key=os.getenv("GROQ_API_KEY"))

    prompt = f"""
    You are an AI business analyst. You are given structured insights from a market intelligence pipeline.
    Convert them into a clear, executive summary for a product manager.
    Make it concise, actionable, and structured into:
    - Key Findings
    - Strategic Recommendations
    - Confidence Levels

    Here are the insights in JSON:
    {json.dumps(insights, indent=4)}
    """

    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",  # Groq LLaMA model
        messages=[
            {"role": "system", "content": "You are a market analyst AI."},
            {"role": "user", "content": prompt},
        ],
        temperature=0.6,
        max_tokens=800
    )

    return response.choices[0].message.content.strip()

def run_summary():
    insights = load_insights()
    summary_text = generate_summary_with_llama(insights)

    os.makedirs(os.path.dirname(SUMMARY_PATH), exist_ok=True)
    with open(SUMMARY_PATH, "w", encoding="utf-8") as f:
        f.write(summary_text)

    print(f" Executive summary saved at {SUMMARY_PATH}")
    print("\n Preview:\n")
    print(summary_text[:800])

if __name__ == "__main__":
    run_summary()
