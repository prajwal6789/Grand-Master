import os
import pandas as pd
import numpy as np
import json

# Paths
COMBINED_PATH = os.path.join("data", "processed", "combined_cleaned.csv")
INSIGHTS_PATH = os.path.join("reports", "insights.json")

def load_data():
    df = pd.read_csv(COMBINED_PATH)
    print(f" Loaded combined dataset: {df.shape[0]} rows, {df.shape[1]} columns")
    return df

def compute_top_categories(df, n=5):
    top = (
        df.groupby("category")["reviews"]
        .sum()
        .sort_values(ascending=False)
        .head(n)
    )
    return {
        "insight": f"Top {n} categories by total reviews",
        "details": top.to_dict(),
        "confidence": 0.9,
        "recommendation": "Focus marketing on these categories for visibility"
    }

def compute_paid_vs_free(df):
    if "price" not in df.columns:
        return None
    df["is_paid"] = df["price"].apply(lambda x: 1 if x > 0 else 0)
    avg_rating = df.groupby("is_paid")["rating"].mean().to_dict()
    return {
        "insight": "Comparison of paid vs free apps by average rating",
        "details": {"free_apps": avg_rating.get(0, None), "paid_apps": avg_rating.get(1, None)},
        "confidence": 0.8,
        "recommendation": "Use this to decide pricing strategies"
    }

def compute_installs_rating_correlation(df):
    if "installs" not in df.columns or df["installs"].isna().all():
        return None
    try:
        corr = df["installs"].corr(df["rating"])
    except Exception:
        corr = None
    return {
        "insight": "Correlation between installs and ratings",
        "details": {"correlation": corr},
        "confidence": 0.7 if corr is not None else 0.3,
        "recommendation": "If correlation is strong, boosting ratings may help installs"
    }

def generate_insights():
    df = load_data()

    insights = []
    insights.append(compute_top_categories(df))
    insights.append(compute_paid_vs_free(df))
    insights.append(compute_installs_rating_correlation(df))

    # Drop None values
    insights = [ins for ins in insights if ins is not None]

    # Save JSON
    os.makedirs(os.path.dirname(INSIGHTS_PATH), exist_ok=True)
    with open(INSIGHTS_PATH, "w") as f:
        json.dump(insights, f, indent=4)

    print(f" Insights saved to {INSIGHTS_PATH}")
    return insights

if __name__ == "__main__":
    insights = generate_insights()
    print(json.dumps(insights, indent=4))
